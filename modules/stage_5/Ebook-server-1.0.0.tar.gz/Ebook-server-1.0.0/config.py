class Config:
    """This class is used to config server."""
    
    pass
