from distutils.core import setup

setup(name="Ebook-server",
      packages=["sentence_processing", "app"],
      scripts=["run.py"],
      py_modules=["config"],
      version="1.0.0",
      description="Finder of word senses and idioms",
      author="Roman Milishchuk",
      author_email="milishchuk@ucu.edu.ua",
      url="https://momka45.pythonanywhere.com/",
      download_url="https://github.com/Momka45/coursework",
      keywords=["wsd", "idiom", "phrasal_verb", "collocation", "word_senses"],
      data_files=[("requirements", ["requirements.txt"]),
      ("idioms", ["expressions.json"])])
